<?php

namespace App\Repository;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Repository\Interfaces\BaseRepositoryInterface;

class BaseRepository implements BaseRepositoryInterface {

    /**
     * @var Model
     */
    protected $model;

    /**
     * @param Model $model
     */
    public function __construct(Model $model = null) {
        $this->model = $model;
    }


    public function all(array $columns = ['*'], array $relations = []): Collection
    {
        return $this->model->with($relations)->get($columns);
    }

    public function find(int $modelId,array $columns = ['*'],array $relations = [],array $appends = []): ?Model {
        return $this->model->select($columns)->with($relations)->findOrFail($modelId)->append($appends);
    }
    
    public function findById(int $modelId,array $columns = ['*'],array $relations = [],array $appends = []): ?Model {
        return $this->model->select($columns)->with($relations)->findOrFail($modelId)->append($appends);
    }
 
    /**
     * @param array $data
     * @return Model
     */
    public function create(array $data = []): ? Model {
        $model = $this->model->create($data);
        return $model->fresh();
    }

    /**
     * @param integer $id
     * @param array $data
     * @return Model
     */
    public function update(int $id, array $data = []) {
        $model = $this->find($id);
        $model->update($data);
       return true;
    }

    /**
     * @param integer $id
     * @return Model
     * @throws \Exception
     */
    public function delete(int $id): ?bool {
       return $this->find($id)->delete();
    }
    
      

    public function with(array $array): ? Model {
        return $this->model->with($array);
    }

    /**
     * @param integer $id
     * @return Model
     * @throws ModelNotFoundException
     */
    public function findOrFail(int $id): ? Model {
        return $this->model->findOrFail($id);
    }

    /**
     * @param string $slug
     * @return Model
     * @throws ModelNotFoundException
     */
    public function findBySlug($slug): ? Model {
        return $this->model->where('slug', $slug)->first();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(): ? Model {
        return $this->model->query();
    }

    /**
     * @param array $attributes
     * @return Model
     */
    public function instance(array $attributes = []): ? Model {
        $model = $this->model;
        return new $model($attributes);
    }

    /**
     * @param int|null $perPage
     * @return mixed
     */
    public function paginate($limit = null, $columns = ['*']) : ? Model{
        return $this->model->paginate($limit);
    }

    public function where($key, $where) : ? Model{
        return $this->model->where($key, $where);
    }
    /**
     * @return array
     */
    public function validatorAttributeNames(array $data = []) {
        return [];
    }
    /**
     * @return Model
     */
    public function getModel() {
        return $this->model;
    }

    
}
