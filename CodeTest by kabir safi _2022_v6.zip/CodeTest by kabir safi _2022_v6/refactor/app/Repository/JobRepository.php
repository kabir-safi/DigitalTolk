<?php

namespace App\Repository;

use App\Models\Repository\Job;
use App\Repository\Interfaces\JobRepositoryInterface;

use App\Repository\BaseRepository;

/**
 * Class BookingRepository
 */
class JobRepository extends BaseRepository implements JobRepositoryInterface {

    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param Model $model
     */
    public function __construct(Job $model) {
        $this->model = $model;
    }
    

}
