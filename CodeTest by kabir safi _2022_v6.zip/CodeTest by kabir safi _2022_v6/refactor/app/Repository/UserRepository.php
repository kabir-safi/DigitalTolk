<?php

namespace App\Repository;

use App\Models\Repository\User;
use App\Repository\Interfaces\UserRepositoryInterface;

use App\Repository\BaseRepository;

/**
 * Class BookingRepository
 */
class UserRepository extends BaseRepository implements UserRepositoryInterface {

    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param Model $model
     */
    public function __construct(User $model) {
        $this->model = $model;
    }
    

}
