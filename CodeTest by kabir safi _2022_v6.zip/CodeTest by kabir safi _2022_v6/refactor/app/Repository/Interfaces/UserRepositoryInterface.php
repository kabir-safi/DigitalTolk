<?php

namespace App\Repository\Interfaces;

use App\Repository\Interfaces\BaseRepositoryInterface;

interface UserRepositoryInterface extends BaseRepositoryInterface {
    
}
