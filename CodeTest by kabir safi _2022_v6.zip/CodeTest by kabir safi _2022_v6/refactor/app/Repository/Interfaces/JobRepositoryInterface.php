<?php

namespace App\Repository\Interfaces;

use App\Repository\Interfaces\BaseRepositoryInterface;

interface JobRepositoryInterface extends BaseRepositoryInterface {
    
}
