<?php

namespace App\Repository\Interfaces;

use App\Repository\Interfaces\BaseRepositoryInterface;

interface BookingRepositoryInterface extends BaseRepositoryInterface {
    
}
