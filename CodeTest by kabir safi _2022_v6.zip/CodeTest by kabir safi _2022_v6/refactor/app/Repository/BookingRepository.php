<?php

namespace App\Repository;

use App\Models\Repository\Booking;
use App\Models\Repository\User;
use App\Repository\Interfaces\BookingRepositoryInterface;
use App\Repository\Interfaces\BaseRepositoryInterface;
use App\Repository\BaseRepository;

/**
 * Class BookingRepository
 */
class BookingRepository extends BaseRepository implements BookingRepositoryInterface {

    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param Model $model
     */
    public function __construct(User $model) {
        $this->model = $model;
    }
    

}
