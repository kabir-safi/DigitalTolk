<?php

namespace App\Models\Repository;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Repository\User;

class Job extends Model {

    use HasFactory;

    public function users() {
        /**
         * user belongs to one user, users table
         * @var bigInt id
         * 
         * */
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

}
