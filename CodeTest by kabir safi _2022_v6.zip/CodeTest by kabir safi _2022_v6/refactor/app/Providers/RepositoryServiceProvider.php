<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repository\BaseRepository;
use App\Repository\BookingRepository;
use App\Repository\UserRepository;
use App\Repository\JobRepository;
use App\Repository\Interfaces\BaseRepositoryInterface;
use App\Repository\Interfaces\BookingRepositoryInterface;
use App\Repository\Interfaces\UserRepositoryInterface;
use App\Repository\Interfaces\JobRepositoryInterface;
class RepositoryServiceProvider extends ServiceProvider
{
/**
 * Register services.
 */
public function register(): void
{
 
        $this->app->bind(BaseRepositoryInterface::class, BaseRepository::class);
        $this->app->bind(BookingRepositoryInterface::class, BookingRepository::class);
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(JobRepositoryInterface::class, JobRepository::class);
}

/**
 * Bootstrap services.
 */
public function boot(): void
{
//
}
}
