<?php

namespace App\Http\Controllers\Repository;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\Interfaces\UserRepositoryInterface;
use App\Repository\Interfaces\BookingRepositoryInterface;
use App\Repository\Interfaces\JobRepositoryInterface;

class BookingController extends Controller {

    /**
     * @var BookingRepository
     */
    private $userRepository;
    private $bookingRepository;
    private $jobRepository;

    /**
     * BookingController constructor.
     * @param BookingRepository $bookingRepository
     */
    public function __construct(UserRepositoryInterface $userRepository, BookingRepositoryInterface $bookingRepository, JobRepositoryInterface $jobRepository) {
        $this->userRepository = $userRepository;
        $this->bookingRepository = $bookingRepository;
        $this->jobRepository = $jobRepository;
    }

    public function index(Request $request) {
        $user = $this->userRepository->find(9);
    }

}
